#CRYPTO_SIMULATOR
This project focuses on frontend development using CSS,HTML and JavaScript. The project allows users to login with a username and trade cryptocurrencies.